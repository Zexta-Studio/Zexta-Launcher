import { XPlayer } from "../util/xPlayer.js";
export declare class Social {
    auth: string;
    constructor(auth: string);
    getProfile(xuid?: string): Promise<XPlayer>;
    getFriends(xuid?: string): Promise<XPlayer[]>;
    xGet(endpoint: string, xuid?: string): Promise<any>;
}
export default Social;
