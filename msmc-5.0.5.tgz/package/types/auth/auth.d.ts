/// <reference types="node" />
/// <reference types="node" />
import EventEmitter from "events";
import type { Server } from "http";
import type { Prompt, AuthEvents, MSToken, MSAuthToken, Framework, Lexcodes, WindowProperties } from "../types.js";
import { Xbox } from "./xbox.js";
export declare class Auth extends EventEmitter implements AuthEvents {
    token: MSToken;
    private app;
    constructor(prompt?: Prompt);
    constructor(token: MSToken);
    createLink(redirect?: string): string;
    emit(eventName: string | symbol, ...args: any[]): boolean;
    load(code: Lexcodes): void;
    login(code: string, redirect?: string): Promise<Xbox>;
    refresh(MS: MSAuthToken): Promise<Xbox>;
    refresh(refreshToken: string): Promise<Xbox>;
    launch(framework: Framework, windowProperties?: WindowProperties): Promise<Xbox>;
    /**
     * Used for a console like login experience.
     * @param callback
     * @param port
     * @returns
     */
    setServer(callback: (xbox: Xbox) => void, redirect?: string, port?: number): Promise<{
        link: string;
        port: number;
        server: Server;
        auth: Auth;
    }>;
    private _get;
}
export default Auth;
