import { Auth } from "./auth.js";
import type { MCProfile, MclcUser, GmllUser, MCToken, Entitlements, MCJWTDecoded } from "../types.js";
import type { Xbox } from "./xbox.js";
export declare class Minecraft {
    readonly mcToken: string;
    readonly profile: MCProfile | undefined;
    readonly parent: Xbox | Auth;
    readonly xuid: string;
    readonly exp: number;
    refreshTkn: string;
    getToken(full: boolean): MCToken;
    constructor(mcToken: string, profile: MCProfile, parent: Xbox);
    constructor(mcToken: string, profile: MCProfile, parent: Auth, refreshTkn: string, exp: number);
    entitlements(): Promise<Entitlements[]>;
    isDemo(): boolean;
    /**
     * A MCLC user object for launching minecraft
     * @param refreshable Should we embed some metadata for refreshable tokens?
     * @returns returns an MCLC user token
     *
     */
    mclc(refreshable?: boolean): MclcUser;
    gmll(): GmllUser;
    refresh(force?: boolean): Promise<this>;
    validate(): boolean;
    _parseLoginToken(): MCJWTDecoded;
}
export default Minecraft;
