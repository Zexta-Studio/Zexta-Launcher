import { Social } from "./social.js";
import { Minecraft } from "./minecraft.js";
import type { Lexcodes, MSAuthToken, XblAuthToken } from "../types.js";
import type { Auth } from "./auth.js";
export declare class Xbox {
    readonly parent: Auth;
    readonly msToken: MSAuthToken;
    readonly xblToken: XblAuthToken;
    readonly exp: number;
    constructor(parent: Auth, MStoken: MSAuthToken, xblToken: XblAuthToken);
    load(code: Lexcodes): void;
    xAuth(RelyingParty?: string): Promise<string>;
    refresh(force?: boolean): Promise<this>;
    getSocial(): Promise<Social>;
    getMinecraft(): Promise<Minecraft>;
    validate(): boolean;
    /**
     * Feed this into the refresh function in the Auth object that generated it.
     * @returns The refresh token
     */
    save(): string;
}
export default Xbox;
