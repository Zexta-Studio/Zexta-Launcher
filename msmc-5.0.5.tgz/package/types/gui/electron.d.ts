import { Auth } from "../auth/auth.js";
declare const _default: (auth: Auth, Windowproperties?: import("../types.js").WindowProperties) => Promise<unknown>;
export default _default;
