import type { WindowProperties } from "../types";
import type { Auth } from "../auth/auth.js";
export declare function getDefaultWinProperties(): WindowProperties;
export declare function launch(auth: Auth, framework: any, windowProperties: any): Promise<import("..").Xbox>;
