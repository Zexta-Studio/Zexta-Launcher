import type { Response } from "node-fetch";
import type { Lexcodes } from "../types";
import type { Auth } from "../auth/auth.js";
/**
 * If the exact code isn't found. The lexicon string is split up and shaved down till it finds a description for the code.
 *
 * For example; error.auth.microsoft will be shortend to error.auth if error.auth.microsoft isn't found
 */
export declare let lexicon: {
    error: string;
    "error.auth": string;
    "error.auth.microsoft": string;
    "error.auth.xboxLive": string;
    "error.auth.xsts": string;
    "error.auth.xsts.userNotFound": string;
    "error.auth.xsts.bannedCountry": string;
    "error.auth.xsts.child": string;
    "error.auth.xsts.child.SK": string;
    "error.auth.minecraft": string;
    "error.auth.minecraft.login": string;
    "error.auth.minecraft.profile": string;
    "error.auth.minecraft.entitlements": string;
    "error.gui": string;
    "error.gui.closed": string;
    "error.gui.raw.noBrowser": string;
    "error.state.invalid": string;
    "error.state.invalid.http": string;
    "error.state.invalid.gui": string;
    "error.state.invalid.redirect": string;
    "error.state.invalid.electron": string;
    load: string;
    "load.auth": string;
    "load.auth.microsoft": string;
    "load.auth.xboxLive": string;
    "load.auth.xboxLive.1": string;
    "load.auth.xboxLive.2": string;
    "load.auth.xsts": string;
    "load.auth.minecraft": string;
    "load.auth.minecraft.login": string;
    "load.auth.minecraft.profile": string;
    "load.auth.minecraft.gamepass": string;
    gui: string;
    "gui.title": string;
    "gui.market": string;
};
export declare function getCode(lexcodes: Lexcodes): any;
export interface ExptOpts {
    ts: Lexcodes;
    response: Response;
}
export declare function error(ts: Lexcodes): void;
export declare function errorResponse(response: Response, ts: Lexcodes): void;
export declare function wrapError(code: string | ExptOpts | any): {
    name: "error" | "error.auth" | "error.auth.microsoft" | "error.auth.xboxLive" | "error.auth.xsts" | "error.auth.xsts.userNotFound" | "error.auth.xsts.bannedCountry" | "error.auth.xsts.child" | "error.auth.xsts.child.SK" | "error.auth.minecraft" | "error.auth.minecraft.login" | "error.auth.minecraft.profile" | "error.auth.minecraft.entitlements" | "error.gui" | "error.gui.closed" | "error.gui.raw.noBrowser" | "error.state.invalid" | "error.state.invalid.http" | "error.state.invalid.gui" | "error.state.invalid.redirect" | "error.state.invalid.electron" | "load" | "load.auth" | "load.auth.microsoft" | "load.auth.xboxLive" | "load.auth.xboxLive.1" | "load.auth.xboxLive.2" | "load.auth.xsts" | "load.auth.minecraft" | "load.auth.minecraft.login" | "load.auth.minecraft.profile" | "load.auth.minecraft.gamepass" | "gui" | "gui.title" | "gui.market";
    opt: ExptOpts;
    message: any;
};
export declare function loadLexiPack(...file: string[]): typeof lexicon;
export declare class LexiLoader {
    auth: Auth;
    constructor(auth: Auth);
    load(code: Lexcodes): void;
}
