import type { Social } from "../auth/social";
export declare class XPlayer {
    auth: Social;
    score: number;
    xuid: string;
    gamerTag: string;
    name: string;
    profilePictureURL: string;
    constructor(user: {
        id: string;
        settings: any[];
    }, auth: Social);
    getFriends(): Promise<XPlayer[]>;
}
export default XPlayer;
