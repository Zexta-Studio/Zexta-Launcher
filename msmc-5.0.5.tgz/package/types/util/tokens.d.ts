import type { Auth } from "../auth/auth.js";
import type { MCToken, MclcUser } from "../types";
import { Minecraft } from "../auth/minecraft.js";
/**Validates MC tokens to check if they're valid. */
/**
 * Gets a Minecraft token from a saved mcToken.
 * @param auth A new instance of the Auth object
 * @param token The mcToken
 * @param refresh Set to true if we should try refreshing the token
 * @returns A newly serialized Minecraft Token.
 *
 * @warning The Xbox object may not be restored using this method!
 */
export declare function fromToken(auth: Auth, token: MCToken): null | Minecraft;
export declare function fromToken(auth: Auth, token: MCToken, refresh?: boolean): Promise<Minecraft>;
/**
 * Gets a Minecraft token from a saved mcToken.
 * @param auth A new instance of the Auth object
 * @param token The mcToken
 * @returns A newly serialized Minecraft Token.
 *
 * @warning The Xbox object may not be restored using this method!
 */
export declare function fromMclcToken(auth: Auth, token: MclcUser, refresh?: boolean): null | Minecraft | Promise<Minecraft>;
