import type { Minecraft } from "../auth/minecraft";
import type { MCToken, MclcUser } from "../types";
export declare function validate(token: MCToken | Minecraft | MclcUser): boolean;
export default validate;
